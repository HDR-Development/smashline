use std::sync::atomic::Ordering;

use crate::{cloning::weapons::{try_get_new_agent, CURRENT_OWNER_KIND, NEW_AGENTS}, create_agent::{LOWERCASE_WEAPON_NAMES, LOWERCASE_WEAPON_OWNER_NAMES}};

pub fn get_weapon_name(id: i32) -> Option<String> {
    let current_owner = CURRENT_OWNER_KIND.load(Ordering::Relaxed);
    let agents = NEW_AGENTS.read();
    if let Some(name) = try_get_new_agent(&agents, id, current_owner).map(|agent| agent.new_name.clone()) {
        Some(name)
    } else {
        LOWERCASE_WEAPON_NAMES.get(id as usize).map(|x| x.to_string())
    }
}

pub fn get_weapon_owner_name(id: i32) -> Option<String> {
    let current_owner = CURRENT_OWNER_KIND.load(Ordering::Relaxed);
    let agents = NEW_AGENTS.read();

    if let Some(name) = try_get_new_agent(&agents, id, current_owner).map(|agent| agent.owner_name.clone()) {
        Some(name)
    } else {
        LOWERCASE_WEAPON_OWNER_NAMES.get(id as usize).map(|x| x.to_string())
    }
}
